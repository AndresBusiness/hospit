package org.udls.masterweb.ce.model;

import android.graphics.Typeface;

/**
 * Created by Andres on 11/28/2017.
 */

public class DataGlobal {

    public static String ConexionApiRest = "http://apirestcore-env.us-east-1.elasticbeanstalk.com/v1/";
    public static Typeface Learners;
    public static Typeface Song;

}
